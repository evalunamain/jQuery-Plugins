$.Carousel = function (el) {
  this.$el = $(el);
  this.activeIdx = 0;
  this.$activeImg = $('div.items img:first-child');
  this.$activeImg.addClass("active");
  var carousel = this;
  $('.slide-left').on('click', function (event) {
    event.preventDefault();
    carousel.slide(-1);
  });

  $('.slide-right').on('click', function (event) {
    event.preventDefault();
    carousel.slide(1);
  });

};

$.Carousel.prototype.slide = function (dir) {
  this.$activeImg.removeClass("active");

  if (dir === -1) {
    this.activeIdx -= 1;
    if (this.activeIdx < 0) {
      this.activeIdx += 7;
    }
    var $img = this.$activeImg = this.$el.find('img').eq(this.activeIdx);
    $img.addClass("active");
    $img.addClass("left");

    window.setTimeout( function() {
      $img.removeClass("left");
    }, 0);

  } else {
      this.activeIdx += 1;
      if (this.activeIdx > 6) {
        this.activeIdx -= 7;
      }
    var $img = this.$activeImg = this.$el.find('img').eq(this.activeIdx);

    $img.addClass("active");
    $img.addClass("right");

    window.setTimeout( function() {
      $img.removeClass("right");
    }, 0);
  }


};


$.fn.carousel = function () {
  return this.each(function () {
    new $.Carousel(this);
  });
};
